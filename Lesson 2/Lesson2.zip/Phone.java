/* Class: Java 2 (CIS 263AA)
*  Author: Sachin Haldipur
*  Exercise 1 and 4
*/


public interface Phone {

    public abstract void call(Person person);

    public abstract void end ();

    public abstract void text ();

}
